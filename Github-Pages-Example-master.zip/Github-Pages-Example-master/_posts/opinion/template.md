---
layout: post
title: 谈谈刚需和360影视
category: opinion
description: 一个看起来很简单的需求，做起来真的有那么困难吗，到底是怎么回事？
---

[BeiYuu]:    http://beiyuu.com  "BeiYuu"
